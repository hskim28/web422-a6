import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-widget',
  templateUrl: './search-widget.component.html'})
export class SearchWidgetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
